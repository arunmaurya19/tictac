package pojoclasses;

public class Customer implements Comparable<Customer> {

	private int user_id;
	private String name;
	private String latitude;
	private String longitude;
	
	public Customer() {
		
	}

	public Customer(int userId, String name,String latitude,String longitude) {
		this.user_id = userId;
		this.name = name;
		this.latitude = latitude;
		this.longitude=longitude;
	}

	public int getUser_id() {
		return user_id;
	}

	public Double getLatitude() {
		return Double.parseDouble(latitude);
	}

	public Double getLongitude() {
		return Double.parseDouble(longitude);
	}

	public String getName() {
		return name;
	}

	@Override
	public int compareTo(Customer otherCustomer) {

		return Integer.compare(getUser_id(), otherCustomer.getUser_id());
	}

   
	@Override
	public String toString() {
		return "Customer [user_id=" + user_id + ", name=" + name + ", latitude=" + latitude + ", longitude=" + longitude
				+ "]";
	}
	
	
}
