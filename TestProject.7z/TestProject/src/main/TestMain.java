package main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import pojoclasses.Customer;
import util.JsonReader;
import util.OutputHelper;

public class TestMain {

	public static void main(String[] args) {
		JsonReader reader = new JsonReader();
		try {
			InputStream inpStream = new FileInputStream("./inputFile/customers.txt");
			List<Object> customerList = reader.parseAsStream(inpStream, Customer.class);

			OutputHelper.getCustomerWithinRange(customerList,
					e -> System.out.println(e.getUser_id() + " " + e.getName()));

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

	}

}
