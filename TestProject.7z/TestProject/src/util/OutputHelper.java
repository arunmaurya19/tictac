package util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import pojoclasses.Coordinates;
import pojoclasses.Customer;

public class OutputHelper {

	private static final Coordinates DublinCordinates = new Coordinates(53.339428d, -6.257664d);

	public static void getCustomerWithinRange(List<Object> customerList, Consumer<Customer> consumer) {

		List<Customer> customerListInRange = getCustomerWithInGivenRange(customerList, 100d);
		
		customerListInRange.stream().sorted().collect(Collectors.toList()).forEach(consumer);
	}

	private static List<Customer> getCustomerWithInGivenRange(List<Object> customerList, double range) {

		List<Customer> result = new ArrayList<Customer>();
		for (Object customer : customerList) {
			Coordinates customerCordinates = new Coordinates(((Customer) customer).getLatitude(),
					((Customer) customer).getLongitude());
			double distance = customerCordinates.distanceWithRespectToOtherCoordinate(DublinCordinates);
			//System.out.println(distance + " "+ ((Customer) customer).getUser_id() + " " +((Customer) customer).getName());
			if (distance <= range) {
				result.add((Customer) customer);
			}
		}

		return result;
	}
}
