package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonReader {

	private ObjectMapper objectMapper = new ObjectMapper();

	public List<Object> parseAsStream(final InputStream stream, final Class entryClass) {

	
		try (Stream<String> lines = new BufferedReader(new InputStreamReader(stream)).lines()) {
			return lines.map(line -> {
				try {

					return objectMapper.readerFor(entryClass).readValue(line);
				} catch (IOException e) {
					e.printStackTrace();
					return null;
				}
			}).filter(Objects::nonNull).collect(Collectors.toList());
		}
		
		
	}

	
}
