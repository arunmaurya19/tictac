package pojoclasses;

public class Coordinates {

	private final static double EarthRadius = 6371.009;
	private double latitude;
	private double longitude;

	public Coordinates(double latitude, double longitude) {
		this.longitude = longitude;
		this.latitude = latitude;

	}

	public double getLatitude() {
		return latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public double distanceWithRespectToOtherCoordinate(Coordinates other) {
		double lat1 = Math.toRadians(this.getLatitude());
		double long1 = Math.toRadians(this.getLongitude());
		double lat2 = Math.toRadians(other.getLatitude());
		double long2 = Math.toRadians(other.getLongitude());

		// great circle distance in radians
		double angle1 = Math
				.acos(Math.sin(lat1) * Math.sin(lat2) + Math.cos(lat1) * Math.cos(lat2) * Math.cos(long1 - long2));

	
		
		return (EarthRadius * angle1);
	}
}
